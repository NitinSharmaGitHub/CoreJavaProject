package com.banking;

import java.sql.Connection;
import java.sql.DriverManager;
public class DBConnect {
    static Connection con; // Global Connection Object
    public static Connection getConnection()
    {
        try {
        	// 1 Load jdbc driver
        	Class.forName("com.mysql.cj.jdbc.Driver");

        	con = DriverManager.getConnection("jdbc:mysql://localhost:3316/bankdb", "root", "abcdef");
        }
        catch (Exception e) {
            System.out.println("Connection Failed!");
        }
 
        return con;
    }
}